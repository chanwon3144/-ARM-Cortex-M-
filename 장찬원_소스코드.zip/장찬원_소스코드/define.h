#define LCDW            (320)
#define LCDH            (240)
#define X_MIN           (0)
#define X_MAX           (LCDW - 1)
#define Y_MIN           (0)
#define Y_MAX           (LCDH - 1)

// Player 설정
#define PLAYER_SIZE_X   (20)
#define PLAYER_SIZE_Y   (20)
#define PLAYER_COLOR    (1)
#define PLAYER_STEP     (10)    // 사용은 안함 (방향 이동 없으니까)
#define JUMP_INIT_VY    (-20)   // 점프 초기 속도
#define GRAVITY         (2)     // 중력 가속도
#define GROUND_HEIGHT   (20)
#define GROUND_COLOR    (2)
#define BACKGROUND_COLOR (5)
#define PLAYER_INTERVAL (10) // 플레이어 이동 주기(ms)

//방해요소(고양이)
#define MAX_CATS            (5)
#define CAT_COLOR           (3)
#define CAT_SIZE            (20)    // 고양이 크기
#define CAT_SPEED           (10)     // 고양이 이동 속도
#define CAT_SPAWN_INTERVAL  (100) // 고양이 생성 주기(ms)
#define CAT_MOVE_INTERVAL   (30) // 고양이 이동 주기(ms)
#define CAT_MIN_DISTANCE    (CAT_SIZE * 4) // 고양이 간격 최소값

//방해요소(올빼미)
#define MAX_OWLS            (3)
#define OWL_COLOR_INDEX     (4)
#define OWL_SIZE_X          (PLAYER_SIZE_X * 1)
#define OWL_SIZE_Y          (PLAYER_SIZE_Y * 5)
#define OWL_SIZE_X_MAX      (PLAYER_SIZE_X * 2)
#define OWL_SIZE_Y_MAX      (PLAYER_SIZE_Y * 7)
#define OWL_MOVEMENT_SPEED  (15)
#define OWL_SPAWN_BASE      (2000) 
#define OWL_MOVE_INTERVAL   (60) // 올빼미 이동 주기(ms)

//아이템(치즈)
#define MAX_CHEESE              (5)
#define CHEESE_SIZE             (10)    // 치즈 크기
#define CHEESE_SPEED            (4)    // 치즈 이동 속도
#define CHEESE_COLOR_INDEX      (1)
#define CHEESE_SPAWN_INTERVAL   (1000) // 치즈 생성 주기(ms)
#define CHEESE_MIN_SIZE         (8) // 치즈 최소 크기
#define CHEESE_MAX_SIZE         (12) // 치즈 최대 크기
#define CHEESE_ANIM_STEP        (1) // 치즈 애니메이션 주기(ms)
#define CHEESE_ANIM_INTERVAL    (100) // 치즈 애니메이션 주기(ms)

//기술
#define CHEESE_FOR_BURST    (5)
#define BURST_DURATION_MS   (3000) // 버스트 지속시간(ms)

#define TIMER_PERIOD        (60)    // 타이머 주기(ms)
#define BASE			    (500)	//BGM 기준 박자(ms)
