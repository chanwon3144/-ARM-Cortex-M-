#include "stm32f10x.h"
#include "option.h"
#include "macro.h"
#include "malloc.h"
#include "lcd.h"
#include "graphics.h"

// Led.c

extern void LED_Init(void);
extern void LED_Display(unsigned int num);
extern void LED_All_On(void);
extern void LED_All_Off(void);

// Uart.c

#define Uart_Init			Uart1_Init
#define Uart_Send_Byte		Uart1_Send_Byte
#define Uart_Send_String	Uart1_Send_String
#define Uart_Printf			Uart1_Printf

extern void Uart1_Init(int baud);
extern void Uart1_Send_Byte(char data);
extern void Uart1_Send_String(char *pt);
extern void Uart1_Printf(char *fmt,...);
extern char Uart1_Get_Char(void);
extern char Uart1_Get_Pressed(void);
extern void Uart1_Get_String(char *string);
extern int Uart1_Get_Int_Num(void);
extern void Uart1_RX_Interrupt_Enable(int en);

// Clock.c

extern void Clock_Init(void);

// Key.c

extern void Key_Poll_Init(void);
extern int Key_Get_Pressed(void);
extern void Key_Wait_Key_Released(void);
extern int Key_Wait_Key_Pressed(void);
extern void Key_ISR_Enable(int en);

// Timer.c

extern void TIM2_Delay(int time);
extern void TIM2_Change_Value(int time);
extern void TIM4_Repeat_Interrupt_Enable(int en, int time);
extern void TIM2_Repeat_Interrupt_Enable(int en, int time);
extern void TIM3_Out_Init(void);
extern void TIM3_Out_Freq_Generation(unsigned short freq);
extern void TIM3_Out_Stop(void);
extern void TIM5_Delay(int time);

// Asm_Function.s

extern unsigned int __get_IPSR(void);

// Sys_Tick.c

extern void SysTick_OS_Tick(unsigned int msec);

// SysTick.c

extern void SysTick_Run(unsigned int msec);
extern int SysTick_Check_Timeout(void);
extern unsigned int SysTick_Get_Time(void);
extern unsigned int SysTick_Get_Load_Time(void);
extern void SysTick_Stop(void);

// Jog_Key.c

extern void Jog_Poll_Init(void);
extern int Jog_Get_Pressed_Calm(void);
extern int Jog_Get_Pressed(void);
extern void Jog_Wait_Key_Released(void);
extern int Jog_Wait_Key_Pressed(void);
extern void Jog_ISR_Enable(int en);

//main.c
extern void Player_Update(void);
extern void Cat_Update(void);
extern void MainLoop(void);
extern void System_Init(void);
extern void Background(void);
extern void Game_Init(void);
extern void Game_Updata_All(void);
extern void Player_Draw(int ci);
extern void Player_Update(void);
extern void Player_Jump_Start(void);
extern void MUSIC_ON(void);
extern void Cat_Init(void); 
extern void Cat_Spawn(void);
extern void Cat_Update(void);
extern void Owl_Init(void);
extern void Owl_Update(void);
extern void Owl_Spawn(void);
extern void Cheese_Init(void);
extern void Cheese_Spawn(void);
extern void Cheese_Update(void);
extern void Draw_Score(void);
extern void Draw_time(void);
extern void Draw_GameOver_Screen(void);
extern void Draw_Start_Menu(void);
extern void ResetGame(void);
extern void GameOver_Cleanup(void);
extern void GAMEOVER_MUSIC_ON(void);