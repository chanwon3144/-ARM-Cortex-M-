#include <stdbool.h>
#include "device_driver.h"
#include <stdlib.h>
#include <stdio.h>
#include <define.h>

static uint16_t cat_move_timer = 0; // 고양이 이동 타이머
static uint16_t cat_spawn_timer = 0; // 고양이 생성 타이머 
static uint16_t next_spawn_interval = CAT_SPAWN_INTERVAL;; // 고양이 생성 타이머

static uint16_t owl_spawn_timer = 0;
static uint16_t next_owl_spawn = OWL_SPAWN_BASE;
static uint16_t owl_move_timer = 0; // 올빼미 이동 타이머

static int cheese_spawn_timer = 0; // 치즈 생성 타이머
static int cheese_anim_timer = 0; // 치즈 애니메이션 타이머
static int cheese_anim_direction = 1; // 치즈 애니메이션 
static int cheese_anim_size = CHEESE_SIZE; // 치즈 애니메이션 크기

static int elapsed_time_ms = 0; // 경과 시간
static int jump_sound_timer = 0; // 점프 사운드 타이머
static int jump_sound_active = 0; // 점프 사운드 활성화 여부
static int gameover_bgm_index = 0; // 게임 오버 BGM 인덱스
int score = 0; // 점수

// Player
typedef struct
{
    int x, y;
    int w, h;
    int vy;          // 현재 y 방향 속도
    int jumping;     // 점프 중 여부 (0: 땅에 있음, 1: 점프중)

} PLAYER_OBJ;
static PLAYER_OBJ Player;
extern PLAYER_OBJ Player;
static int prev_x, prev_y, prev_w, prev_h;

// 방해요소
typedef struct
{
    int x, y;
    int w, h;
    int size;
    int active;
    int prev_size;

}CAT_OBJ, OWL_OBJ, CHEESE_OBJ;
static CAT_OBJ Cats[MAX_CATS];
static OWL_OBJ Owls[MAX_OWLS];
static CHEESE_OBJ Cheese[MAX_CHEESE];

// 기술
typedef enum
{
    RUN_STATE_NORMAL,
    RUN_STATE_BURST
} RUN_STATE;
static RUN_STATE run_state = RUN_STATE_NORMAL; // 현재 상태
static int cheese_count = 0; // 치즈 개수
static int burst_timer_ms = 0; // 버스트 타이머
static int speed_mul = 1; // 속도 배수 (버스트 상태에서 증가)

//진행
typedef enum 
{
    GAME_STATE_MENU,
    GAME_STATE_PLAYING,
    GAME_STATE_GAMEOVER
} GameState;
static GameState game_state = GAME_STATE_MENU;
static bool start_drawn = false;//게임 시작 여부
static bool gameover_drawn = false;// Game Over 화면 한 번만 그리기용 플래그

// 컬러 배열
static unsigned short color[] = {RED, YELLOW, GREEN, BLUE, WHITE, BLACK};
extern unsigned short color[];

// 외부 변수
extern volatile int TIM4_expired;
extern volatile int TIM2_expired;
extern volatile int Jog_key_in;
extern volatile int Jog_key;

static void Buzzer_Beep(unsigned char tone);
int i = 0;

//충돌검사
static inline bool Check_Collision_Rect(
    int ax, int ay, int aw, int ah,
    int bx, int by, int bw, int bh)
    {
        return  (ax < bx + bw) &&
                (ax + aw > bx) &&
                (ay < by + bh) &&
                (ay + ah > by);
    }

//Tim4 루프
void MainLoop(void)
{     
    if (!TIM4_expired) return;
    TIM4_expired = 0;

    if(jump_sound_active)
    {
        jump_sound_timer += TIMER_PERIOD;
        if(jump_sound_timer >= 300)
        {
            jump_sound_active = 0;
            TIM3_Out_Stop();
        }
    }

    //메뉴
    if(game_state == GAME_STATE_MENU)
    {
        if(!start_drawn)
        {
            Lcd_Draw_Back_Color(BLACK);
            Draw_Start_Menu();
            start_drawn = true;
        }
        return;
    }

    //게임오버
    if(game_state == GAME_STATE_GAMEOVER) 
    {
        if (!gameover_drawn) 
        {   
            //Lcd_Clr_Screen();
            Lcd_Draw_Back_Color(BLACK);
            Draw_GameOver_Screen();
            gameover_drawn = true;
        }
        
        if (Jog_key_in)
        {
            if(!gameover_drawn)
            {
                Lcd_Draw_Back_Color(BLACK);
                Draw_GameOver_Screen();
                gameover_drawn = true;
            }
        }
        return;
    }

    // 타이머 누적
    cat_spawn_timer  += TIMER_PERIOD;
    owl_spawn_timer  += TIMER_PERIOD;
    cat_move_timer   += TIMER_PERIOD;
    owl_move_timer   += TIMER_PERIOD;
    cheese_spawn_timer += TIMER_PERIOD;
    elapsed_time_ms += TIMER_PERIOD;

    // 스폰
    if (cat_spawn_timer >= next_spawn_interval) 
    {
        cat_spawn_timer = 0;
        Cat_Spawn();
        next_spawn_interval = (rand() % 5000) + 500;
    }

    if(owl_spawn_timer >= next_owl_spawn)
    {
        owl_spawn_timer = 0;
        Owl_Spawn();
        next_owl_spawn = (rand() % 5000) + 500;
    }

    if(cheese_spawn_timer >= CHEESE_SPAWN_INTERVAL)
    {
        cheese_spawn_timer = 0;
        Cheese_Spawn();
    }

    Game_Updata_All();
}

//BGM 곡 데이터
#if 1
enum key {C1, C1_, D1, D1_, E1, F1, F1_, G1, G1_, A1, A1_, B1, C2, C2_, D2, D2_, E2, F2, F2_, G2, G2_, A2, A2_, B2};
enum note {N16=BASE/4, N8=BASE/2, N4=BASE, N2=BASE*2, N1=BASE*4};
const int song1[][2] = 
{
    {E1, N8}, {E1, N8}, {E1, N4},
    {C1, N8}, {E1, N4}, {G1, N2},
    {G1, N4}, {C1, N8}, {G1, N4},
    {E1, N4}, {A1, N2}, {B1, N2},
    {A1_, N4}, {A1, N4}
};

const int gameover_bgm[][2] = 
{
    {C2, N8}, {G1, N8}, {E1, N8},
    {A1, N4}, {B1, N4}, {A1, N8},
    {A1_, N8}, {G1, N4}, {E1, N8},
    {C1, N8}, {D1, N8}, {B1, N2}
};
const int JUMP_SOUND_KEY[] =  {C2, C2_, D2, D2_, E2, F2, F2_, G2, G2_, A2, A2_, B2};

//Timer3 음표 설정정 
static void Buzzer_Beep(unsigned char tone)
{
	const static unsigned short tone_value[] = {261,277,293,311,329,349,369,391,415,440,466,493,523,554,587,622,659,698,739,783,830,880,932,987};

	TIM3_Out_Freq_Generation(tone_value[tone]);

}

//BGM START
void MUSIC_ON(void)
{  
    Buzzer_Beep(song1[i][0]);
    TIM2_Change_Value(song1[i+1][1]);

    i++;

    if(i == (sizeof(song1)/sizeof(song1[0]))) 
    {
        i=0;
    }
}

void GAMEOVER_MUSIC_ON(void)
{
  if(gameover_bgm_index >= sizeof(gameover_bgm)/sizeof(gameover_bgm[0]))
  {
    gameover_bgm_index = 0;
    TIM2_Repeat_Interrupt_Enable(0,1);
    return;
  }
    Buzzer_Beep(gameover_bgm[gameover_bgm_index][0]);
    TIM2_Change_Value(gameover_bgm[gameover_bgm_index][1]);
    gameover_bgm_index++;
}

#endif

//시스템 초기화
void System_Init(void)
{
    Clock_Init();
    LED_Init();
    Key_Poll_Init();
    Uart1_Init(115200);

    SCB->VTOR = 0x08003000;
    SCB->SHCSR = 7 << 16;
    srand(TIM4->CNT);
}

//배경그리기
void Background(void)
{
    Lcd_Draw_Box(0, 0, LCDW, LCDH, color[BACKGROUND_COLOR]);
    
    Lcd_Draw_Box(0, LCDH - GROUND_HEIGHT, LCDW, GROUND_HEIGHT, color[GROUND_COLOR]);
}
//점수표시
void Draw_Score(void)
{
    Lcd_Printf(2,  2,
        color[PLAYER_COLOR], color[BACKGROUND_COLOR],
        1, 1,
        "Score:%04d",
        score);
}
//시간표시
void Draw_time(void)
{
    int total_time = elapsed_time_ms / 1000;
    int mm = total_time / 60;
    int ss = total_time % 60;

    Lcd_Printf(230, 2,
        color[PLAYER_COLOR], color[BACKGROUND_COLOR],
        1, 1,
        "Time=%02d:%02d",
        mm, ss);

}
void Draw_Start_Menu(void)
{
    Lcd_Clr_Screen();      

    // 중앙에 START
    Lcd_Printf((LCDW/2)-50, (LCDH/2)-20,
    color[PLAYER_COLOR], color[BACKGROUND_COLOR],
    2, 2, " Jump Cheese ");

    Lcd_Printf((LCDW/2)-60, (LCDH/2)+10,
    color[PLAYER_COLOR], color[BACKGROUND_COLOR],
    1, 1, "Press KEY5 to Start!");
}
void Draw_GameOver_Screen(void)
{
    Lcd_Clr_Screen();      
  
    // 중앙에 GAME OVER
    Lcd_Printf((LCDW/2)-40, (LCDH/2)-8,
               color[PLAYER_COLOR], color[BACKGROUND_COLOR],
               1, 1, "GAME OVER");
    // 최종 점수
    char buf[16];

    sprintf(buf, "SCORE:%04d", score);
    Lcd_Printf((LCDW/2)-40, (LCDH/2)+8,
               color[PLAYER_COLOR], color[BACKGROUND_COLOR],
               1, 1, buf);
}

//게임 초기화
void Game_Init(void)
{
    Lcd_Clr_Screen();
    Background();

    Cat_Init();
    Owl_Init();
    Cheese_Init();

    Player.x = 50;
    Player.y = LCDH - GROUND_HEIGHT - PLAYER_SIZE_Y;
    Player.w = PLAYER_SIZE_X;
    Player.h = PLAYER_SIZE_Y;
    Player.vy = 0;
    Player.jumping = 0;


    Player_Draw(PLAYER_COLOR);

    LED_All_On();
    LED_Display(0x10);
}
void Game_Updata_All(void)
{
    Player_Draw(BACKGROUND_COLOR);
    Player_Update();

    int i;

    if (run_state == RUN_STATE_BURST) 
    {
        burst_timer_ms += TIMER_PERIOD;
        if (burst_timer_ms >= BURST_DURATION_MS) 
        {
            run_state = RUN_STATE_NORMAL;
        }
    }
    
    //충돌 검사
    else if(run_state != RUN_STATE_BURST)
    {
        for (i = 0; i < MAX_CATS; i++) 
        {
            if (Cats[i].active &&
                Check_Collision_Rect(Player.x, Player.y, Player.w, Player.h,
                                    Cats[i].x, Cats[i].y, Cats[i].size, Cats[i].size)) {
                game_state = GAME_STATE_GAMEOVER;
                return;  // 더 이상 그리지 않고 즉시 빠져나감
            }
        }

        for (i = 0; i < MAX_OWLS; i++) 
        {
            if (Owls[i].active &&
                Check_Collision_Rect(Player.x, Player.y, Player.w, Player.h,
                                    Owls[i].x, Owls[i].y, Owls[i].w, Owls[i].h)) {
                game_state = GAME_STATE_GAMEOVER;
                return;
            }
        }
    }

    speed_mul = (run_state == RUN_STATE_BURST) ? 2 : 1;

    Cat_Update();
    Owl_Update();
    Cheese_Update();

    Draw_Score();
    Draw_time();
}   
void ResetGame(void)
{
    // 1) 게임 상태
    game_state = GAME_STATE_PLAYING;
    gameover_drawn = false;

    // 2) 점수·시간 초기화
    score = 0;
    elapsed_time_ms = 0;
    cheese_count = 0;

    // 3) 버스트 상태 초기화
    run_state = RUN_STATE_NORMAL;
    burst_timer_ms = 0;
    speed_mul = 1;

    // 4) 타이머 초기화
    cat_spawn_timer = 0;
    next_spawn_interval = CAT_SPAWN_INTERVAL;
    cat_move_timer = 0;

    owl_spawn_timer = 0;
    next_owl_spawn = OWL_SPAWN_BASE;
    owl_move_timer = 0;

    cheese_spawn_timer = 0;
    cheese_anim_timer = 0;
    cheese_anim_direction = 1;
    cheese_anim_size = CHEESE_SIZE;

    int i;
    for(i=0; i<MAX_CATS; i++)
    {
        Cats[i].active = 0;
    }
    for(i=0; i<MAX_OWLS; i++)
    {
        Owls[i].active = 0;
    }
    for(i=0; i<MAX_CHEESE; i++)
    {
        Cheese[i].active = 0;
    }
   
    Game_Init();
    return;
}
void GameOver_Cleanup(void)
{
    //Lcd_Draw_Box(prev_x, prev_y, prev_w, prev_h, color[BACKGROUND_COLOR]);
    Lcd_Draw_Box(0, 0, LCDH, LCDW, color[BACKGROUND_COLOR]);

    int i;
    for(i=0; i<MAX_CATS; i++)
    {
        if(Cats[i].active)
        {
            Lcd_Draw_Box(Cats[i].x-100, Cats[i].y, Cats[i].size+100, Cats[i].size, color[BACKGROUND_COLOR]);
            Cats[i].active = 0;
        }
    }

    for(i=0; i<MAX_OWLS; i++)
    {
        if(Owls[i].active)
        {
            Lcd_Draw_Box(Owls[i].x, Owls[i].y, Owls[i].w+100, Owls[i].h+10, color[BACKGROUND_COLOR]);
            Owls[i].active = 0;
        }
    }

    for(i = 0; i < MAX_CHEESE; i++)
    {
        if(Cheese[i].active)
        {
            Lcd_Draw_Box(Cheese[i].x, Cheese[i].y, Cheese[i].prev_size + 100, Cheese[i].prev_size + 10, color[BACKGROUND_COLOR]);
            Cheese[i].active = 0;
        }
    }
}

//플레이어
void Player_Draw(int ci)
{
    int color_idx = (run_state == RUN_STATE_BURST) ? 0 : ci;

    int draw_x = Player.x;
    int draw_y = Player.y;
    int draw_w = Player.w;
    int draw_h = Player.h;

    // if (run_state == RUN_STATE_BURST)
    // {
    //     draw_x -= 0;
    //     draw_y -= 0;
    //     draw_w += 0;
    //     draw_h += 0;
    // }

    // 현재 위치 저장
    prev_x = draw_x;
    prev_y = draw_y;
    prev_w = draw_w;
    prev_h = draw_h;

    Lcd_Draw_Box(draw_x, draw_y, draw_w, draw_h, color[color_idx]);
}
void Player_Jump_Start(void)
{
    if (Player.jumping == 0)
    {
        Player.vy = JUMP_INIT_VY;
        Player.jumping = 1;

        
        Buzzer_Beep(JUMP_SOUND_KEY[rand() % (sizeof(JUMP_SOUND_KEY)/sizeof(JUMP_SOUND_KEY[0]))]);
        jump_sound_timer = 0;
        jump_sound_active = 1;
    }
}
void Player_Update(void)
{
    // 기존 위치 지우기 (달리기 상태까지 고려한 이전 크기만큼)
    Lcd_Draw_Box(prev_x, prev_y, prev_w, prev_h, color[BACKGROUND_COLOR]);

    if (Player.jumping)
    {
        Player.y += Player.vy;
        Player.vy += GRAVITY;

        if (Player.y + Player.h >= LCDH - GROUND_HEIGHT)
        {
            Player.y = LCDH - GROUND_HEIGHT - Player.h;
            Player.vy = 0;
            Player.jumping = 0;
        }
    }

    Player_Draw(PLAYER_COLOR);
}

//고양이
void Cat_Init(void) 
{
    int i;
    for (i = 0; i < MAX_CATS; i++) 
    {
        Cats[i].active = 0;
    }
}
void Cat_Update(void) 
{
    if (cat_move_timer < CAT_MOVE_INTERVAL) return;
    cat_move_timer = 0;

    int i;
    for (i = 0; i < MAX_CATS; i++) 
    {
        CAT_OBJ *c = &Cats[i];
        if (!c->active) continue;

        int old_x = c->x;
        c->x -= CAT_SPEED  * speed_mul; // 속도 배수 적용

        // 1) 완전 사라진 경우 (비활성화)
        if (c->x + c->size < 0) 
        {
            int ex = old_x - c->size;
            int ew = c->size * 2;
            // 화면에 걸쳐 있을 때만 지우기
            if (ex < X_MAX && (ex + ew) > X_MIN) 
            {
                int dx = (ex < X_MIN) ? X_MIN : ex;
                int dw = (dx + ew > X_MAX + 1) ? (X_MAX + 1 - dx) : ew;
                Lcd_Draw_Box(dx, c->y, dw, c->size, color[BACKGROUND_COLOR]);
            }
            c->active = 0;
        }
        // 2) 화면 안으로 들어오는 경우
        else 
        {
            int erase_x = old_x - c->size;
            int erase_w = c->size * 2;
            // 화면에 걸쳐 있을 때만 지우기
            if (erase_x < X_MAX && (erase_x + erase_w) > X_MIN) 
            {
                int dx = (erase_x < X_MIN) ? X_MIN : erase_x;
                int dw = (dx + erase_w > X_MAX + 1) ? (X_MAX + 1 - dx) : erase_w;
                Lcd_Draw_Box(dx, c->y, dw, c->size, color[BACKGROUND_COLOR]);
            }
            // 새 위치 삼각형 그리기
            Lcd_Draw_Triangle(c->x, c->y, c->size, color[CAT_COLOR]);
        }
    }
}
void Cat_Spawn(void) 
{
    int i;
    // 최소 간격 검사(생략)

    for (i = 0; i < MAX_CATS; i++) 
    {
        CAT_OBJ *c = &Cats[i];
        if (!c->active) 
        {
            c->size   = CAT_SIZE;
            c->y      = LCDH - GROUND_HEIGHT - CAT_SIZE;
            c->x      = LCDW + c->size;    // 화면 밖으로 완전 스폰
            c->active = 1;
            break;
        }
    }
}

//올빼미
void Owl_Init(void)
{
    int i;
    for(i=0; i<MAX_OWLS; i++)
    {
        Owls[i].active = 0;
    }
}
void Owl_Spawn(void)
{
    int active_count = 0;
    int i;

    // 현재 활성화된 올빼미 수 확인
    for(i = 0; i < MAX_OWLS; i++)
    {
        if (Owls[i].active) active_count++;
    }

    // 최대 수 제한
    if (active_count >= MAX_OWLS) return;

    // 실제 생성
    for(i = 0; i < MAX_OWLS; i++)
    {
        OWL_OBJ *o = &Owls[i];

        if (!o->active)
        {
            o->active = 1;

            o->w = OWL_SIZE_X_MAX;

            // 랜덤 세로 크기 (최소는 절반 크기)
            int min_h = OWL_SIZE_Y_MAX / 2;
            o->h = (rand() % (OWL_SIZE_Y_MAX - min_h + 1)) + min_h;

            o->x = LCDW - o->w;
            o->y = 0;

            Lcd_Draw_Box(o->x, o->y, o->w, o->h, color[OWL_COLOR_INDEX]);
            break;
        }
    }
}
void Owl_Update(void)
{
    if (owl_move_timer < OWL_MOVE_INTERVAL) return;
    owl_move_timer = 0;

    int i;
    for (i = 0; i < MAX_OWLS; i++)
    {
        OWL_OBJ *o = &Owls[i];
        if (!o->active) continue;

        int old_x = o->x;
        int move_dx = (OWL_MOVEMENT_SPEED * speed_mul); // 속도 배수 적용

        // 이동
        o->x -= OWL_MOVEMENT_SPEED * speed_mul; // 속도 배수 적용

        // 화면 밖이면 전체 영역 제거
        if ((o->x + o->w) < 0)
        {
            Lcd_Draw_Box(old_x, o->y, o->w, o->h, color[BACKGROUND_COLOR]);
            o->active = 0;
        }
        else
        {
            // 꼬리 자국만 지우기 (기존 오른쪽 끝 영역)
            int erase_x = old_x + o->w - move_dx;
            if (erase_x < LCDW) // 화면 안에 있을 때만 지우기
            {
                Lcd_Draw_Box(erase_x, o->y, move_dx, o->h, color[BACKGROUND_COLOR]);
            }

            // 새 위치 그리기
            Lcd_Draw_Box(o->x, o->y, o->w, o->h, color[OWL_COLOR_INDEX]);
        }
    }
}

//치즈
void Cheese_Init(void)
{
    int i;
    for(i=0; i<MAX_CHEESE; i++)
    {
        Cheese[i].active = 0;
    }
    cheese_spawn_timer = 0;
}
void Cheese_Spawn(void)
{
    int i;
    // 최소 간격 검사(생략)

    for (i = 0; i < MAX_CHEESE; i++) 
    {
        if(Cheese[i].active) continue;

        int jump_h = (JUMP_INIT_VY * JUMP_INIT_VY) / (2 * GRAVITY);
        int min_y = Player.y - jump_h;
        if(min_y < 0) min_y = 0;

        int y = (rand() % (Player.y - min_y + 1)) + min_y;
        Cheese[i].x = LCDW;
        Cheese[i].y = y;
        Cheese[i].active = 1;
        Cheese[i].prev_size = cheese_anim_size;
        break;   
    }
}
void Cheese_Update(void)
{
    cheese_anim_timer += TIMER_PERIOD;
    if (cheese_anim_timer >= CHEESE_ANIM_INTERVAL) 
    {
        cheese_anim_timer = 0;
        cheese_anim_size += cheese_anim_direction;
    
        if (cheese_anim_size >= CHEESE_MAX_SIZE || cheese_anim_size <= CHEESE_MIN_SIZE) 
        {
            cheese_anim_direction *= -1;
            cheese_anim_size += cheese_anim_direction;  // 범위 내 유지
        }
    }

    int i;
    for(i=0; i<MAX_CHEESE; i++)
 {
        CHEESE_OBJ *c = &Cheese[i];
        if (!c->active) continue;

        // 이전 위치 지우기
        Lcd_Draw_Box(c->x, c->y, c->prev_size, c->prev_size, color[BACKGROUND_COLOR]);

        // 이동
        c->x -= CHEESE_SPEED * speed_mul; // 속도 배수 적용

        // 화면 밖 → 제거
        if (c->x + cheese_anim_size < 0) {
            c->active = 0;
            continue;
        }

        if(Check_Collision_Rect(
            Player.x, Player.y, Player.w, Player.h,
            c->x, c->y, CHEESE_SIZE, CHEESE_SIZE)) 
        {
            c->active = 0;
            score += 10;
            cheese_count++;
            if(cheese_count >= CHEESE_FOR_BURST) 
            {
                run_state = RUN_STATE_BURST;
                burst_timer_ms = 0;
                cheese_count = 0;
            }
            continue;
        }

        // 새 위치 그리기 (맨 마지막에 출력돼야 함)
        Lcd_Draw_Box(c->x, c->y, cheese_anim_size, cheese_anim_size, color[CHEESE_COLOR_INDEX]);
        c->prev_size = cheese_anim_size;
    }
}

void Main(void)
{
    System_Init();
    Uart_Printf("Jump Game Start\n");
    Lcd_Init(3);
    Jog_Poll_Init();
    Jog_ISR_Enable(1);
    Uart1_RX_Interrupt_Enable(1);
    Lcd_Clr_Screen();
    
    // TIM2, TIM4: 주기 반복 인터럽트
    TIM4_Repeat_Interrupt_Enable(1, TIMER_PERIOD);
	TIM2_Repeat_Interrupt_Enable(1, 1);
	TIM3_Out_Init();

    game_state = GAME_STATE_MENU;
    start_drawn = false;
    gameover_drawn = false;

    for (;;)
    {
        // 1) 게임 메뉴
        if (game_state == GAME_STATE_MENU)
        {
            if(TIM2_expired)
            {
                TIM2_expired = 0;
                MUSIC_ON(); // BGM 재생
            }

            if(!start_drawn)
            {   
                Draw_Start_Menu();
                start_drawn = true;
            }

            if(Jog_key_in)
            {
                Jog_key_in = 0;
                if(Jog_key == 5)
                {
                    TIM3_Out_Stop();
                    Lcd_Clr_Screen();
                    Lcd_Draw_Back_Color(BLACK);
                    ResetGame();
                    start_drawn = false;
                }
            }
            continue;
        }

         // 2) 플레이 중
        else if (game_state == GAME_STATE_PLAYING) 
        {
            MainLoop();  // 타이머 & 충돌 & 스폰 전부 이 안에서 처리

            if (Jog_key_in && Jog_key == 0) 
            {
                Jog_key_in = 0;
                Player_Jump_Start();
            }
        }

        // 3) 게임 오버
        else if (game_state == GAME_STATE_GAMEOVER) 
        {

            if(TIM2_expired)
            {
                TIM2_expired = 0;
                GAMEOVER_MUSIC_ON(); // BGM 재생
            }

            if (!gameover_drawn) 
            {
                gameover_bgm_index = 0;
                TIM3_Out_Init(); // Buzzer 초기화
                GameOver_Cleanup(); // 이전 게임 오버 화면 지우기
                Lcd_Draw_Back_Color(BLACK) ;
                Draw_GameOver_Screen();
                gameover_drawn = true;
            }

            if (Jog_key_in) 
            {
                Uart_Printf("DBG: Jog_key_in=%d, Jog_key=%d\n", Jog_key_in, Jog_key);
            }

            if (Jog_key_in && Jog_key == 5) 
            {
                Jog_key_in = 0;
                TIM3_Out_Stop();
                Lcd_Clr_Screen();
                ResetGame();           // 다시 PLAYING 으로
                gameover_drawn = false; // 다음 오버 때 다시 그려주기
            }
        }
    }
}  